@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
title 飞友工作室 · 一键部署到 GitHub Pages

rem ============ 配置（按需改这一行即可） ============
set "REPO_PATH=E:\louis\github\wingworkstudio.github.io"
set "REMOTE=https://github.com/wingworkstudio/wingworkstudio.github.io.git"
set "COMMIT_MSG=Refactor: 站点重构 + 熵值CAPTCHA 部署"
rem ===============================================

echo.
echo  ==============================================
echo   飞友工作室 WingWorksStudio - 一键部署
echo   目标目录: %REPO_PATH%
echo  ==============================================
echo.

rem --- 0. 检查 git ---
where git >nul 2>nul
if errorlevel 1 (
    echo [X] 未检测到 git，请先安装: https://git-scm.com/download/win
    echo     安装时务必勾选 "Add Git to PATH"
    pause
    exit /b 1
)

rem --- 1. 进入目录 ---
if not exist "%REPO_PATH%" (
    echo [X] 目录不存在: %REPO_PATH%
    echo     请先解压 zip 到该路径，或修改本脚本顶部 REPO_PATH
    pause
    exit /b 1
)
cd /d "%REPO_PATH%" || (echo [X] 无法进入目录 & pause & exit /b 1)

rem --- 2. 确认目录非空 ---
for %%i in (*) do goto :hasfiles
echo [X] 目录为空，请确认 zip 已正确解压（里面应有 index.html 等）
pause
exit /b 1
:hasfiles

rem --- 3. 初始化 / 关联远程 ---
if not exist ".git" (
    echo [+] 初始化 git 仓库...
    git init
    git branch -M main
) else (
    echo [~] 已存在 .git，跳过 init
)
git remote -v | findstr /i "origin" >nul 2>nul
if errorlevel 1 (
    echo [+] 关联远程: %REMOTE%
    git remote add origin "%REMOTE%"
) else (
    echo [~] 远程 origin 已存在，更新为: %REMOTE%
    git remote set-url origin "%REMOTE%"
)

rem --- 4. 暂存 + 提交 ---
echo [+] 暂存所有文件...
git add .
echo.
git status --short
echo.
echo [+] 提交...
git commit -m "%COMMIT_MSG%" || (
    echo [~] 没有新的改动需要提交（若确为首次，请检查上方 status）
)

rem --- 5. 推送 ---
echo [+] 推送到 main 分支...
git push -u origin main
if errorlevel 1 (
    echo.
    echo [X] 推送失败，常见原因：
    echo     1) 未配置身份: git config --global user.name "你的昵称"
    echo                       git config --global user.email "你的邮箱"
    echo     2) 凭据错误: 密码需用 Personal Access Token
    echo        （GitHub - Settings - Developer settings - PAT, 勾选 repo）
    echo     3) 远程已存在内容且历史冲突: 可先执行
    echo        git pull origin main --rebase  后再 push
    pause
    exit /b 1
)

echo.
echo  ==============================================
echo   [V] 推送成功！
echo  ==============================================
echo.
echo   下一步（首次部署需手动开启一次）:
echo     1. 打开 https://github.com/wingworkstudio/wingworkstudio.github.io/settings/pages
echo     2. Source 选择 [main] 分支，目录选 [/ (root)]
echo     3. 保存后等待 1~2 分钟
echo     4. 访问 https://wingworkstudio.github.io
echo.
echo   本地预览: 双击 start.bat  或直接运行
echo             python -m http.server 8000
echo             然后浏览器开 http://localhost:8000
echo.
pause
endlocal
