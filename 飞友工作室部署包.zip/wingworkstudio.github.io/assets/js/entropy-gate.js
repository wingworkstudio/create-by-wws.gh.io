/**
 * 飞友工作室 · 熵值检测（香农信息熵 CAPTCHA）
 * ---------------------------------------------------------------
 * 放行条件：拖动轨迹的「归一化香农信息熵」达到阈值，才视为"人类自然拖动"。
 *
 * 原理：
 *   1. 拖动过程中按时间采样拇指位置，得到离散序列 X = {x₁, x₂, … , xₙ}
 *   2. 对位置序列差分，得到「速度（相邻位移）」序列 vᵢ = |xᵢ − xᵢ₋₁|
 *   3. 速度归一化到 [0, 1] 后均匀分桶，统计频次得到概率分布 pᵢ
 *   4. 香农熵  H = −Σ pᵢ · log₂(pᵢ)，值域 [0, log₂(K)]
 *   5. 归一化  Ĥ = H / log₂(K) ∈ [0, 1]
 *
 * 语义：
 *   - 脚本/匀速直线拖拽 → 速度几乎恒定 → 速度差集中在 0 → 分布尖锐 → H 偏低 → 不放行
 *   - 人手自然拖动（速度变化、微抖动、回退）→ 速度差分散 → 分布平坦 → H 偏高 → 放行
 *   - 采用速度差而非位置，避免「拖到尽头必然填满所有桶」导致的误判
 *   - 同时要求进度 p ≥ 1（拖到尽头），防止「原地高频抖动刷熵」
 *
 * 两种使用模式（由 data 属性切换）：
 *   - gateway 模式（默认）：解锁后跳转 index.html
 *       在 gateway.html 的 slider 上无需额外配置
 *   - inline 模式：解锁后显示本页被遮挡的主内容
 *       在 index.html 的 slider 上写 data-entropy-mode="inline"
 *       被遮挡的内容容器写 data-entropy-content
 *
 * ⚠️ 仅为入口交互趣味性，不构成鉴权 / 安全防护。
 * --------------------------------------------------------------- */
(function () {
  "use strict";

  var slider = document.getElementById("slider");
  var thumb = document.getElementById("sliderThumb");
  var text = document.getElementById("sliderText");
  if (!slider || !thumb) return;

  // ===== 可调参数 =====
  var BUCKETS = 16;        // 分桶数 K（决定熵理论上限 log₂K = 4）
  var SAMPLE_MIN = 12;     // 最少采样点数（太少无法估计分布）
  // 归一化熵阈值：真实人手拖动实测 H≈0.87–0.92，取 0.85 既保证人手稳定通过，
  // 又能稳定拦截匀速/脚本直线（H≈0.2 甚至更低）。可在 assets/js/entropy-gate.js 调整。
  var ENTROPY_THRESHOLD = 0.85;
  var PROGRESS_REQUIRED = 1.0;  // 必须拖到尽头

  // 模式判定：inline = 解锁本页内容；否则 = 跳转
  var mode = slider.getAttribute("data-entropy-mode") === "inline" ? "inline" : "gateway";

  // ===== DOM 引用（仪表）=====
  var valueEl = document.getElementById("entropyValue");
  var barEl = document.getElementById("entropyBar");
  var progressEl = document.getElementById("entropyProgress");
  var hintEl = document.getElementById("entropyHint");
  var formulaEl = document.getElementById("entropyFormula");

  var samples = [];        // 采样位置序列
  var maxRange = 1;        // 滑块可用行程（px），懒计算
  var dragging = false;

  function getMax() {
    maxRange = slider.offsetWidth - thumb.offsetWidth - 8;
    if (maxRange < 1) maxRange = 1;
    return maxRange;
  }

  // 把拇指夹紧到 [0, max]
  function setThumb(x) {
    var clamped = Math.max(0, Math.min(x, getMax()));
    thumb.style.left = clamped + "px";
    return clamped;
  }

  // ===== 香农熵计算 =====
  // 对「相邻采样的速度（位移）」序列求熵，而非对位置本身求熵。
  //
  // 为什么用速度：
  //   拖动到尽头时，无论匀速还是抖动，位置都会覆盖整个 [0, max] 区间，
  //   若直接对位置分桶，匀速直线也会填满所有桶 → 熵偏高 → 误判为「人类」。
  //   而速度分布：匀速 → 速度恒定 → 分布尖锐 → 低熵；
  //               人手自然抖动/变速 → 速度分散 → 分布平坦 → 高熵。
  //
  // 归一化基准：使用「本次拖动的速度序列自身最大值 maxVel」作为基准，
  //   而非 maxRange。因为单步位移（几 px）相对滑块行程（数百 px）差两个数量级，
  //   若除以 maxRange，所有速度都会被压到第 0 桶，熵恒≈0 无法区分。
  //   除以 maxVel 后，速度分布被自适应展开到 [0, 1]，可正确度量离散度。
  //
  // samples: number[]  返回归一化熵 Ĥ ∈ [0,1]
  function shannonEntropyNormalized(arr) {
    var n = arr.length;
    if (n < SAMPLE_MIN) return 0;

    // 1) 由位置序列差分得到速度序列（相邻采样点的位移绝对值）
    var vel = new Array(n - 1);
    var maxVel = 0;
    for (var i = 1; i < n; i++) {
      var d = Math.abs(arr[i] - arr[i - 1]);
      vel[i - 1] = d;
      if (d > maxVel) maxVel = d;
    }
    if (maxVel === 0) return 0; // 完全没动 → 熵为 0

    // 2) 速度除以本次最大值，归一化到 [0, 1]
    var norm = new Array(vel.length);
    for (var j = 0; j < vel.length; j++) norm[j] = vel[j] / maxVel;

    // 3) 均匀分桶统计概率分布
    var K = BUCKETS;
    var counts = new Array(K);
    for (var m = 0; m < K; m++) counts[m] = 0;
    for (var q = 0; q < norm.length; q++) {
      var idx = Math.floor(norm[q] * (K - 1));
      if (idx < 0) idx = 0;
      if (idx >= K) idx = K - 1;
      counts[idx]++;
    }

    // 4) H = −Σ pᵢ log₂(pᵢ)，归一化到 [0, 1]
    var H = 0;
    var log2K = Math.log2(K);
    var total = norm.length;
    for (var k = 0; k < K; k++) {
      if (counts[k] === 0) continue;
      var p = counts[k] / total;
      H -= p * Math.log2(p);
    }
    return H / log2K;
  }

  // ===== 仪表刷新 =====
  function refresh(progress) {
    var H = samples.length >= SAMPLE_MIN ? shannonEntropyNormalized(samples) : 0;
    var pct = Math.round(progress * 100);
    if (valueEl) valueEl.textContent = H.toFixed(2);
    if (barEl) barEl.style.width = Math.round(H * 100) + "%";
    if (progressEl) progressEl.textContent = String(pct);
    if (formulaEl) {
      formulaEl.innerHTML =
        "H = −Σ pᵢ log₂pᵢ · 归一化 · 进度 p = <span id=\"entropyProgress\">" + pct + "</span>%";
    }
    return H;
  }

  // ===== 放行判定 =====
  function evaluate() {
    var progress = samples.length > 0 ? Math.max.apply(null, samples) / maxRange : 0;
    var H = refresh(progress);
    var reached = progress >= PROGRESS_REQUIRED;

    if (reached && H >= ENTROPY_THRESHOLD) {
      unlock(H);
      return true;
    }
    if (reached && H < ENTROPY_THRESHOLD) {
      // 拖到了但熵不够（典型：匀速/脚本直线）→ 复位，提示重拖
      if (hintEl) hintEl.textContent = "轨迹过于规律（H=" + H.toFixed(2) + "），请自然拖动再试";
    }
    return false;
  }

  function unlock(H) {
    slider.classList.add("is-unlocked");
    thumb.textContent = "✓";
    if (text) text.textContent = mode === "inline" ? "检测通过 · 正在解密内容" : "进入工作室";
    if (hintEl) hintEl.textContent = "熵值验证通过 · H=" + H.toFixed(2) + " ≥ " + ENTROPY_THRESHOLD.toFixed(2);

    if (mode === "inline") {
      // inline 模式：显示本页被遮挡的主内容，隐藏检测卡片
      revealContent();
    } else {
      // gateway 模式：跳转主页
      setTimeout(function () { window.location.href = "index.html"; }, 350);
    }
  }

  // ===== inline 模式：解锁后揭示内容 =====
  function revealContent() {
    var gate = document.getElementById("entropyGate");
    var content = document.querySelector("[data-entropy-content]");
    if (gate) {
      gate.classList.add("is-revealed");
      // 稍后从文档流移除，腾出空间
      setTimeout(function () { gate.style.display = "none"; }, 400);
    }
    if (content) {
      content.classList.add("is-revealed");
      content.setAttribute("aria-hidden", "false");
    }
  }

  // ===== 交互：拖拽采样 =====
  var startX = 0;
  function start(e) {
    dragging = true;
    samples = [];
    getMax();
    startX = (e.touches ? e.touches[0].clientX : e.clientX) - thumb.offsetLeft;
  }
  function move(e) {
    if (!dragging) return;
    var clientX = e.touches ? e.touches[0].clientX : e.clientX;
    var x = setThumb(clientX - startX);
    samples.push(x);
    var progress = samples.length > 0 ? Math.max.apply(null, samples) / maxRange : 0;
    refresh(progress);
  }
  function end() {
    if (!dragging) return;
    dragging = false;
    var passed = evaluate();
    if (!passed) setThumb(0);  // 未达标，拇指复位，可重新拖动
  }

  thumb.addEventListener("mousedown", start);
  thumb.addEventListener("touchstart", start, { passive: true });
  window.addEventListener("mousemove", move);
  window.addEventListener("touchmove", move, { passive: true });
  window.addEventListener("mouseup", end);
  window.addEventListener("touchend", end);
})();
