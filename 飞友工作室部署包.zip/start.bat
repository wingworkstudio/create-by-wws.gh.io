@echo off
chcp 65001 >nul
setlocal
set "REPO_PATH=E:\louis\github\wingworkstudio.github.io"
cd /d "%REPO_PATH%" 2>nul || (
    echo [X] 目录不存在: %REPO_PATH%
    pause & exit /b 1
)
echo 启动本地预览: http://localhost:8000  （按 Ctrl+C 停止）
python -m http.server 8000 2>nul || (
    echo python 不可用，改用 npx:
    npx --yes serve -l 8000
)
endlocal
